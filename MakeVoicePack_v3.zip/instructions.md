# 角色的解释说明

## Player:
- 'coach', 'gambler', 'mechanic', 'producer'
== 'Coach', 'Nick', 'Ellis', 'Rochelle'

- 'biker', 'teengirl', 'manager', 'namvet'
=='Francis', 'Zoey', 'Louis', 'Bill'


## NPC:
- 'whitaker':地图【死亡中心】中的枪店老板
- 'arenaheli':地图【黑色狂欢节】中救援关的直升机驾驶员
- 'virgil':地图【沼泽激战】中的船长
- 'soldier1':地图【教区】中的"鳄鱼爸爸"
- 'soldier2':地图【教区】中的第7组士兵

- 'chopper_pilot':其中有部分是地图【毫不留情】中呼叫仁慈医院的直升机驾驶员。
其他的不清楚。
- 'churchguy':地图【死亡丧钟】中的教堂男孩([Ding Dong~])
- 'boatman':地图【死亡丧钟】中的救援船人员
- 'planepilot':地图【静寂时分】救援关中的运输机飞行员
- 'soldier':地图【血腥收获】中救援关中屋子里对讲机对面的士兵
- '05_military':？？？我也不知道
